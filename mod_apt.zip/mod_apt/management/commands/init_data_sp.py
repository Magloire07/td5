
from django.core.management.base import BaseCommand
from mod_yum.models import YumRepo
from time import strftime


class Command(BaseCommand):

    def _update_empty_dates_YumRepo(self):
        return YumRepo.objects.filter(date="").update(date=strftime("%Y-%m-%d %H:%M"))

    def _create_default_data_for_YumRepoNode(self):
        return YumRepo.objects.filter(date="").update(date=strftime("%Y-%m-%d %H:%M"))

    def handle(self, *args, **options): # @UnusedVariable
        self._update_empty_dates_YumRepo()
