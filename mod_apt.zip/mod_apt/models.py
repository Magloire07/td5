from django.db import models
from django.urls import reverse_lazy
from django.utils.translation import gettext_lazy as _

from core.models import Node
from core.utils import get_root_by_natural_key, root_natural_key



class Apt(models.Model):
    """
    Dépôt apt configuré pour être utilisé dans un noeud
    """
    # Associated role (not required)
    role = models.ForeignKey('core.ServerRole', verbose_name=_("Server Role"), related_name="apt_repo",
                             on_delete=models.SET_NULL, null=True, blank=True, )

    node = models.ForeignKey(Node, on_delete=models.CASCADE, related_name='apts')
    # URL du dépôt distant
    repository_line = models.CharField(_("base URL"), max_length=255, blank=True, null=True,
                                help_text=_('apt base_url helptext'))

    class Meta:
        verbose_name = _("apt repository")
        verbose_name_plural = _("apt repositories")


    def attach_role_slave(self, _parent_fname, node):
        try:
            return node.apt
        except Apt.DoesNotExist:
            return None

    def get_absolute_url(self):
        root_url = self.get_role_root().get_absolute_url()
        return f"{root_url}#apt"

    def natural_key(self):
        return root_natural_key(self)
    natural_key.dependencies = ['core.Node', 'core.ServerRole']

