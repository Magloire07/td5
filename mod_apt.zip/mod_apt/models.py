from django.db import models
from django.utils.translation import gettext_lazy as _

from core.models import BaseRoleForeignKey
from core.utils import get_root_by_natural_key, root_natural_key


class Apt(BaseRoleForeignKey):
    """
    Ligne de dépôt apt (sources.list) configurée pour un nœud ou un rôle serveur.
    """
    # URL du dépôt distant (ligne sources.list)
    repository_line = models.CharField(
        _("apt source line"), max_length=255, blank=True, null=True,
        help_text=_('apt base_url helptext')
    )

    # Topic pour l'intégration dans la vue nœud/rôle
    topic_name = "apt"
    topic_title = _("apt")

    class Meta:
        verbose_name = _("apt repository")
        verbose_name_plural = _("apt repositories")
        ordering = ("repository_line",)

    def __str__(self):
        return f'{self._meta.verbose_name} : {self.repository_line or self.pk}'

    def natural_key(self):
        return root_natural_key(self)
    natural_key.dependencies = ['core.Node', 'core.ServerRole']
