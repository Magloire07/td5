
from django import forms
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

from core.forms.generic import GenericModelForm

from mod_apt.models import Apt


from django import forms
from django.core.exceptions import ValidationError

class AptForm(GenericModelForm):
    def __init__(self, node, role, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["node"].widget = forms.widgets.HiddenInput()
        self.fields["role"].widget = forms.widgets.HiddenInput()
    repository_line = forms.CharField(
        label="Ligne de dépôt APT",
        widget=forms.TextInput(attrs={'placeholder': 'deb [trusted=yes] http://repo.infra.dgfip/pub/...'})
    )
    class Meta:
        model = Apt
        fields = ("node","role","repository_line") 

    def clean_repository_line(self, *args, **kwargs):
        super().clean(*args, **kwargs, )
        data = self.cleaned_data['repository_line'].strip()
        if not (data.startswith('deb ') or data.startswith('deb-src ')):
            raise ValidationError("La ligne doit commencer par 'deb' ou 'deb-src'.")
        return data
