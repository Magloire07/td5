
from django import forms
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

from core.forms.generic import GenericModelForm
from mod_apt.models import Apt


class AptForm(GenericModelForm):
    def __init__(self, node, role, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["node"].widget = forms.widgets.HiddenInput()
        self.fields["role"].widget = forms.widgets.HiddenInput()

    repository_line = forms.CharField(
        label=_("apt source line"),
        widget=forms.TextInput(attrs={
            'placeholder': 'deb [trusted=yes] http://repo.infra.dgfip/pub/...'
        })
    )

    class Meta:
        model = Apt
        fields = ("node", "role", "repository_line")

    def clean_repository_line(self):
        data = self.cleaned_data['repository_line'].strip()
        if not (data.startswith('deb ') or data.startswith('deb-src ')):
            raise ValidationError(
                _("La ligne doit commencer par 'deb' ou 'deb-src'.")
            )
        return data
