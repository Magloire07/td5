// yumrepo_form javascript
$(document).ready(function(){

	/*$( "input[type='submit']" ).click(function( event ) {
	  alert( "Handler for .ssssubmit() called." );
	  event.preventDefault();
	});*/

	$('#id_identifier').autocomplete({
	    source : function( request, response ){ 
	    $.ajax({
	            url : '/yum/security-pack/api/get_data/',
	            dataType : 'json',    
	            delay: 500,
	            minLength: 3,
	            data : {
	                q : $('#id_identifier').val(),
	                s: $('#id_repo_type').val()
	            },   
	            focus: function( ) {
	            	return false;
	            },
	            success : function(data){ 
	            	if($('#lst').length) {
            			$('#lst').remove();
                    }
                    $('#id_identifier').after("<ul id='lst'></ul>");
	            	if(data.length > 0) {
	            		$( data ).each(function( index ) {	
						  $('#lst').append("<li data='"+ JSON.stringify(data[index]) +"''>" + data[index].fields.identifier  + "</li>");
						});
						$("#lst").highlight($('#id_identifier').val());
	            	} else {
	            		if(data['Error']) {
	            			console.log(data['Error']);
	            			$('#lst').append('<li>' + data['Error'] + '</li>');
	            		}
	            		
	            	} 
	            }
	        });
	    }
	});

	//Si l'utilisateur click sur une suggestion alors on la passer comme valeur du champ text #id_identifier
	$('body').on('click', '#lst li', function () {
		if($( this ).attr("data").length > 0) {
			var obj = jQuery.parseJSON( $( this ).attr("data") );
			$('#id_identifier').val( obj.fields.identifier );
			$('#id_description').val( obj.fields.description );
	     	$('#lst').remove();
		}
	});
	 	
 	//On doit supprimer la liste des suggestions si l'utilisateur vide le champ text
	$('#id_identifier').keyup(function(){
	    if(!$(this).val()) {
	    	$('#lst').remove();
	    	$('#id_identifier').val( "" );
			$('#id_description').val( "" );
	    }
	});
	
	// ou si il change de type de depot
	$('#id_repo_type').change(function(){
    	$('#lst').remove();
    	$('#id_identifier').val( "" );
		$('#id_description').val( "" );
	});
});