
from django.urls import path

from .views import apt

app_name = 'apt'

urlpatterns = [

    path(
        "apt/<int:pk>/add/",
       apt.AptCreateView.as_view(),
        name="add_apt",
    ),
    path(
        "apt/<int:pk>/edit/",
       apt.AptUpdateView.as_view(),
        name="edit_apt",
    ),
    path(
        "apt/<int:pk>/delete",
       apt.AptDeleteView.as_view(),
        name="delete_apt",
    ),
]
