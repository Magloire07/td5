
from core.exports.signals import export_node
from core.utils.dispatch import receiver
from mod_export_ansible.exports.base import AnsibleYamlExporter
from mod_export_ldap.exports import LdapNode, LdifExporter
from mod_yum.models import YumRepo


@receiver(export_node, sender=AnsibleYamlExporter)
def export_yaml_node(sender, instance, node, parent, **kwargs):
    """
    Export des utilisateurs et groupes d'un noeud
    """



    
    omega_node=node["_node"]
    if omega_node.yum_repos.count() :
        if not node.get("repos"):
            node["repos"]=[]
        for yumrepo in omega_node.yum_repos.all():
            if yumrepo.repo_type != YumRepo.SECURITY_PACK_REPO_TYPE:
                repo={}
                repo["name"]=yumrepo.identifier
                if yumrepo.base_url:
                    repo["baseurl"]=yumrepo.base_url
                if yumrepo.gpgcheck:
                    repo["gpgcheck"]=1
                else:
                    repo["gpgcheck"]=0
                if yumrepo.gpgkey:
                    repo["gpgkey"]=yumrepo.gpgkey
                if yumrepo.enabled:
                    repo["enabled"]=1
                else:
                    repo["enabled"]=0
                if yumrepo.keepalive:
                    repo["keepalive"]=1
                if yumrepo.timeout:
                    repo["timeout"]=yumrepo.timeout
                if yumrepo.description:
                    repo["description"]=yumrepo.description
                if yumrepo.cost:
                    repo["cost"]=yumrepo.cost
                if yumrepo.exclude:
                    repo["exclude"]=yumrepo.exclude
                if yumrepo.failovermethod:
                    repo["failover_method"]=yumrepo.failovermethod
                if yumrepo.http_caching:
                    repo["http_caching"]=yumrepo.http_caching
                if yumrepo.include:
                    repo["include"]=yumrepo.include
                if yumrepo.includepkgs:
                    repo["includepkgs"]=yumrepo.includepkgs
                if yumrepo.metadata_expire:
                    repo["metadata_expire"]=yumrepo.metadata_expire
                if yumrepo.mirrorlist:
                    repo["mirror_list"]=yumrepo.mirrorlist
                if yumrepo.priority:
                    repo["priority"]=yumrepo.priority
                if yumrepo.proxy:
                    repo["proxy"]=yumrepo.proxy
                if yumrepo.proxy_password:
                    repo["proxy_password"]=yumrepo.proxy_password
                if yumrepo.proxy_username:
                    repo["proxy_username"]=yumrepo.proxy_username
                if yumrepo.bandwidth:
                    repo["bandwidth"]=yumrepo.bandwidth
                if yumrepo.gpgcakey:
                    repo["gpg_cakey"]=yumrepo.gpgcakey
                if yumrepo.metalink:
                    repo["meta_link"]=yumrepo.metalink
                if yumrepo.mirrorlist_expire:
                    repo["mirrorlist_expire"]=yumrepo.mirrorlist_expire
                if yumrepo.retries:
                    repo["retries"]=yumrepo.retries
                if yumrepo.sslcacert:
                    repo["ssl_cacert"]=yumrepo.sslcacert
                if yumrepo.sslclientcert:
                    repo["ssl_client_cert"]=yumrepo.sslclientcert
                if yumrepo.sslclientkey:
                    repo["ssl_client_key"]=yumrepo.sslclientkey
                if yumrepo.throttle:
                    repo["throttle"]=yumrepo.throttle
                if yumrepo.deltarpm_metadata_percentage:
                    repo["deltarpm_metadata_percentage"]=yumrepo.deltarpm_metadata_percentage
                if yumrepo.deltarpm_percentage:
                    repo["deltarpm_percentage"]=yumrepo.deltarpm_percentage

                if yumrepo.protect:
                    repo["protect"]=1
                if yumrepo.repo_gpgcheck:
                    repo["repo_gpgcheck"]=1
                if yumrepo.s3_enabled:
                    repo["s3_enabled"]=1
                if yumrepo.skip_if_unavailable:
                    repo["skip_if_unavailable"]=1
                if yumrepo.sslverify:
                    repo["ssl_verify"]=1
                if (yumrepo.assumeyes):
                    repo["assume_yes"]=1
                if yumrepo.enablegroups:
                    repo["enable_groups"]=1
                node["repos"].append(repo)

        if omega_node.http_repos.count():
            for httprepo in omega_node.http_repos.all():
                if not node.get("http_repos"):
                    node["http_repos"]=[]
                node["http_repos"].append({"name":httprepo.name,"path":httprepo.path})





# @receiver(export_node, sender=LdifExporter)
# def export_ldap_securitypack(sender, instance, node, parent, **kwargs): # @UnusedVariable
#     """
#     Export de la configuration security pack.
#     """
#     if omega_node.security_pack:
#         ou_yum = instance.get_ou("yum", parent=node)

#         ldap_node = LdapNode(model_object=omega_node.security_pack, parent=ou_yum)
#         ldap_node.set_dn("securitypack", omega_node.security_pack.identifier)
#         ldap_node.set("objectClass", ["securityPack",])
#         ldap_node.set("securitypack", omega_node.security_pack.identifier)

#         return ou_yum

