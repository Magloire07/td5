
from core.exports.signals import export_node
from core.utils.dispatch import receiver
from mod_export_ansible.exports.base import AnsibleYamlExporter


@receiver(export_node, sender=AnsibleYamlExporter)
def export_yaml_node(sender, instance, node, parent, **kwargs):
    """
    Export Ansible YAML des dépôts apt (sources.list) d'un nœud.
    """
    omega_node = node["_node"]
    apts = omega_node.apts.all()

    if apts.exists():
        if not node.get("apt_repos"):
            node["apt_repos"] = []
        for apt in apts:
            repo = {}
            if apt.repository_line:
                repo["line"] = apt.repository_line
            node["apt_repos"].append(repo)
