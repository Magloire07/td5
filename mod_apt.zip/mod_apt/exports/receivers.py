
from core.exports.signals import export_node
from core.utils.dispatch import receiver
from mod_export_ldap.exports import LdapNode, LdifExporter
from mod_yum.models import YumRepo


@receiver(export_node, sender=LdifExporter)
def export_ldap_node(sender, instance, node, parent, **kwargs): # @UnusedVariable
    """
    Export de la configuration yum.
    """
    if node.instance.yum_repos.count() or node.instance.http_repos.count():
        ou_yum = instance.get_ou("yum", parent=node)

        for yumrepo in node.instance.yum_repos.all():
            if yumrepo.repo_type != YumRepo.SECURITY_PACK_REPO_TYPE:
                ldap_node = LdapNode(model_object=yumrepo, parent=ou_yum)
                ldap_node.set_dn("yumrepo", yumrepo.identifier)
                ldap_node.set("objectClass", ["yumrepoObject",])
                ldap_node.set("yumrepoBaseurl", yumrepo.base_url)
                ldap_node.set("yumrepoEnabled", "1" if yumrepo.enabled else "0")
                ldap_node.set("yumrepoTimeout", yumrepo.timeout)
                ldap_node.set("yumrepoName", yumrepo.description)
                ###############################################
                if node.instance.use_networkmanager:
                    ldap_node.set("yumrepoCost", yumrepo.cost)
                    if yumrepo.enablegroups:
                        ldap_node.set("yumrepoEnablegroups", "TRUE")
                    ldap_node.set("yumrepoExclude", yumrepo.exclude)
                    ldap_node.set("yumrepoFailovermethod", yumrepo.failovermethod)
                    if yumrepo.gpgcheck:
                        ldap_node.set("yumrepoGpgcheck", "TRUE")
                    ldap_node.set("yumrepoGpgkey", yumrepo.gpgkey)
                    ldap_node.set("yumrepoHttpCaching", yumrepo.http_caching)
                    ldap_node.set("yumrepoInclude", yumrepo.include)
                    ldap_node.set("yumrepoIncludepkgs", yumrepo.includepkgs)
                    if yumrepo.keepalive:
                        ldap_node.set("yumrepoKeepalive", "TRUE")
                    ldap_node.set("yumrepoMetadataExpire", yumrepo.metadata_expire)
                    ldap_node.set("yumrepoMirrorlist", yumrepo.mirrorlist)
                    ldap_node.set("yumrepoPriority", yumrepo.priority)
                    if yumrepo.protect:
                        ldap_node.set("yumrepoProtect", "TRUE")
                    ldap_node.set("yumrepoProxy", yumrepo.proxy)
                    ldap_node.set("yumrepoProxyPassword", yumrepo.proxy_password)
                    ldap_node.set("yumrepoProxyUsername", yumrepo.proxy_username)
                    if yumrepo.ensure == "absent":
                        ldap_node.set("ensure", yumrepo.ensure)
                    ldap_node.set("yumrepoBandwidth", yumrepo.bandwidth)
                    ldap_node.set("yumrepoGpgcakey", yumrepo.gpgcakey)
                    ldap_node.set("yumrepoMetalink", yumrepo.metalink)
                    ldap_node.set("yumrepoMirrorlistExpire", yumrepo.mirrorlist_expire)
                    if yumrepo.repo_gpgcheck:
                        ldap_node.set("yumrepoRepoGpgcheck","TRUE" )
                    ldap_node.set("yumrepoRetries", yumrepo.retries)
                    if yumrepo.s3_enabled:
                        ldap_node.set("yumrepoS3Enabled", "TRUE")
                    if yumrepo.skip_if_unavailable:
                        ldap_node.set("yumrepoSkipIfUnavailable", "TRUE")
                    ldap_node.set("yumrepoSslcacert", yumrepo.sslcacert)
                    ldap_node.set("yumrepoSslclientcert", yumrepo.sslclientcert)
                    ldap_node.set("yumrepoSslclientkey", yumrepo.sslclientkey)
                    if yumrepo.sslverify:
                        ldap_node.set("yumrepoSslverify", "TRUE")
                    ldap_node.set("yumrepoThrottle", yumrepo.throttle)
                    if (yumrepo.assumeyes):
                        ldap_node.set("yumrepoAssumeyes", "TRUE")
                    ldap_node.set("yumrepoDeltarpmMetadataPercentage", yumrepo.deltarpm_metadata_percentage)
                    ldap_node.set("yumrepoDeltarpmPercentage", yumrepo.deltarpm_percentage)

        for httprepo in node.instance.http_repos.all():
            ldap_node = LdapNode(model_object=httprepo, parent=ou_yum)
            ldap_node.set_dn("httprepo", httprepo.name)
            ldap_node.set("objectClass", ["httprepoObject",])
            ldap_node.set("httprepoPath", httprepo.path)

        return ou_yum


@receiver(export_node, sender=LdifExporter)
def export_ldap_securitypack(sender, instance, node, parent, **kwargs): # @UnusedVariable
    """
    Export de la configuration security pack.
    """
    if node.instance.security_pack:
        ou_yum = instance.get_ou("yum", parent=node)

        ldap_node = LdapNode(model_object=node.instance.security_pack, parent=ou_yum)
        ldap_node.set_dn("securitypack", node.instance.security_pack.identifier)
        ldap_node.set("objectClass", ["securityPack",])
        ldap_node.set("securitypack", node.instance.security_pack.identifier)

        return ou_yum

