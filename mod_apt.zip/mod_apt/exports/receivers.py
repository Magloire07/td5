
from core.exports.signals import export_node
from core.utils.dispatch import receiver
from mod_export_ldap.exports import LdapNode, LdifExporter


@receiver(export_node, sender=LdifExporter)
def export_ldap_node(sender, instance, node, parent, **kwargs):  # @UnusedVariable
    """
    Export de la configuration apt (sources.list).
    """
    apts = node.instance.apts.all()
    if apts.exists():
        ou_apt = instance.get_ou("apt", parent=node)

        for apt in apts:
            ldap_node = LdapNode(model_object=apt, parent=ou_apt)
            ldap_node.set_dn("aptrepo", str(apt.pk))
            ldap_node.set("objectClass", ["aptrepoObject"])
            ldap_node.set("aptrepoLine", apt.repository_line)

        return ou_apt
