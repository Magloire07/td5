
import logging
from django.apps import AppConfig
logger = logging.getLogger("omega.mod_apt")


class AptConfig(AppConfig):
    name = 'mod_apt'
    verbose_name = 'Gestion de la configuration apt.'

    def ready(self):
        self.connect_signal()

    def connect_signal(self):
        from mod_apt.views.receivers.node import build_node_view  # noqa
        from mod_apt.views.receivers.serverrole import build_serverrole_view  # noqa
        from mod_apt.exports.receivers import export_ldap_node  # noqa
        from mod_apt.imports.receivers import import_puppet_node  # noqa
        from mod_apt.exports.ansible_receivers import export_yaml_node  # noqa
