
from django.dispatch import receiver
from django.utils.translation import gettext_lazy as _

from core.views.node import NodeDetailView
from core.views.generic.signals import pre_get_context



@receiver(pre_get_context, sender=NodeDetailView)
def build_node_view(view, **kwargs): # @UnusedVariable
    view.add_module_template(
                             "mod_apt/node_detail.html", 
                             priority=62, 
                             topic=11, 
                             module_id="apt",
                             module_title="Apt", 
                             )
