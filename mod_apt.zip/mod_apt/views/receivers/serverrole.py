
from django.dispatch import receiver
from django.utils.translation import gettext_lazy as _
from core.views.server_role import ServerRoleDetailView
from core.views.generic.signals import pre_get_context

module_id="apt" 
module_title=_("Apt")


@receiver(pre_get_context, sender=ServerRoleDetailView)
def build_serverrole_view(view, **kwargs): # @UnusedVariable
    view.add_module_template(
                             "mod_apt/serverrole_detail.html", 
                             priority=53, 
                             topic=9, 
                             module_id=module_id,
                             module_title=module_title, 
                             )

