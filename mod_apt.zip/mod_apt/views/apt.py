from django.utils.translation import gettext_lazy as _

from core.models import Node
from core.views.generic import (
    inject_model_instance,
    RoleOrNodeChildCreateView,
    RoleOrNodeChildUpdateView,
    RoleOrNodeChildDeleteView,
)
from mod_apt.forms import AptForm
from mod_apt.models import Apt


class AptCreateView(inject_model_instance(RoleOrNodeChildCreateView, Node)):
    model = Apt
    form_class = AptForm
    auth_scheme = 'write'


class AptUpdateView(RoleOrNodeChildUpdateView):
    model = Apt
    form_class = AptForm


class AptDeleteView(RoleOrNodeChildDeleteView):
    model = Apt
    auth_scheme = 'write'
