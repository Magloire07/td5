import json
from requests.exceptions import ConnectionError
from django.contrib import messages
from django.conf import settings
from django.core import serializers
from django.urls import reverse_lazy
from django.utils.translation import gettext_lazy as _

from core.models import Node
from core.views.generic import (inject_model_instance,
                               RoleOrNodeChildDeleteView, RoleOrNodeChildUpdateView,RoleOrNodeChildCreateView, GenericUpdateView
                               )
from mod_apt.forms import AptForm
from mod_apt.models import Apt
from django.shortcuts import get_object_or_404
class AptCreateView(inject_model_instance(RoleOrNodeChildCreateView, Node)):
    model = Apt
    form_class = AptForm
    auth_scheme = 'write'


    def dispatch(self, request, *args, **kwargs):
            # Récupère l'ID du nœud depuis l'URL (vérifiez si c' side 'node_pk' ou 'pk' dans votre urls.py)
            node_pk = kwargs.get('node_pk') or kwargs.get('pk')
            self.node = get_object_or_404(Node, pk=node_pk)
            return super().dispatch(request, *args, **kwargs)

    def get_initial(self):
        initial = super().get_initial()
        # Pré-remplit la clé étrangère du nœud dans le formulaire crispy
        if hasattr(self, 'node'):
            initial['node'] = self.node.pk
        return initial
    def get_success_url(self):
        # Retourne sur la vue du nœud suite à l'ajout réussi
        if hasattr(self, 'node'):
            return reverse_lazy("core:view_node", kwargs={"pk": self.node.pk})
        return "/"
    @property
    def abort_url(self):
        """
        Force l'URL d'annulation à utiliser get_success_url() au lieu de 
        chercher la méthode manquante 'get_list_url' sur le modèle Apt.
        """
        return str(self.get_success_url())


class AptUpdateView(RoleOrNodeChildUpdateView):
    model = Apt
    form_class = AptForm

    def get_success_url(self):
        """
        Retourne sur la vue du nœud ou du rôle parent suite à une modification réussie.
        """
        # Récupère l'objet Apt en cours de modification
        obj = self.get_object()
        if obj.node:
            return reverse_lazy("core:view_node", kwargs={"pk": obj.node.pk})
        elif obj.role:
            # Ajustez le nom de la vue si le nom de la route pour un rôle est différent
            return reverse_lazy("core:view_role", kwargs={"pk": obj.role.pk})
        return "/"

    @property
    def abort_url(self):
        """
        Force l'URL d'annulation à utiliser get_success_url().
        """
        return str(self.get_success_url())
    
class AptDeleteView(RoleOrNodeChildDeleteView):
    model = Apt
    auth_scheme = 'write'




