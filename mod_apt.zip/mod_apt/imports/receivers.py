
from django.core.exceptions import ObjectDoesNotExist

from core.utils.dispatch import receiver
from core.imports.signals import import_node

from mod_import_puppetws.imports import PuppetPlatformImporter
from mod_apt.models import Apt
import logging


logger = logging.getLogger("omega.mod_apt")


@receiver(import_node, sender=PuppetPlatformImporter)
def import_puppet_node(sender, instance, node, source, **kwargs):  # @UnusedVariable
    """
    Import de la configuration apt depuis Puppet.
    Importe les lignes sources.list configurées dans les classes Puppet.
    """
    apt_sources = source['properties'].get("classes", {}).get("apt::source", {})
    for name, properties in apt_sources.items():
        try:
            repository_line = properties.get("location", "")
            if not repository_line:
                continue
            Apt.objects.get_or_create(
                node=node,
                repository_line=repository_line,
            )
        except Exception as error:
            msg = f"Impossible d'importer la source apt : name={name}, properties={properties}"
            instance.error(msg)
            logger.error(error)
