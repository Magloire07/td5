
from django.core.exceptions import ObjectDoesNotExist
from django.db.utils import InternalError

from core.utils.dispatch import receiver
from core.imports.signals import import_node

from mod_import_puppetws.imports import PuppetPlatformImporter
from mod_yum.models import YumRepo, HttpRepo
import logging


logger = logging.getLogger("omega.mod_yum")


def get_yumrepo(platformversion, identifier, properties):
    try:
        return platformversion.yum_repos.get(identifier=identifier)
    except ObjectDoesNotExist:
        logger.info("Yum repo does not exist so we create it")
        repo = YumRepo.objects.create(
            platform_version=platformversion,
            identifier=identifier,
            base_url=properties.get("baseurl"),
            enabled=properties.get("enabled", "1").lower() in ["1", "yes", "on"],
            description=properties.get("name"),
            timeout = properties.get("test"),
            cost = properties.get("cost"),
            enablegroups = properties.get("enablegroups"),
            exclude = properties.get("exclude"),
            failovermethod = properties.get("failovermethod"),
            gpgcheck = properties.get("gpgcheck"),
            gpgkey = properties.get("gpgkey"),
            http_caching = properties.get("http_caching"),
            include = properties.get("include"),
            includepkgs = properties.get("includepkgs"),
            keepalive = properties.get("keepalive"),
            metadata_expire = properties.get("metadata_expire"),
            mirrorlist = properties.get("mirrorlist"),
            priority = properties.get("priority"),
            protect = properties.get("protect"),
            proxy = properties.get("proxy"),
            proxy_password = properties.get("proxy_password"),
            proxy_username = properties.get("proxy_username"),
            ensure = properties.get("ensure"),
            bandwidth = properties.get("bandwidth"),
            gpgcakey = properties.get("gpgcakey"),
            metalink = properties.get("metalink"),
            mirrorlist_expire = properties.get("mirrorlist_expire"),
            repo_gpgcheck = properties.get("repo_gpgcheck"),
            retries = properties.get("retries"),
            s3_enabled = properties.get("s3_enabled"),
            skip_if_unavailable = properties.get("skip_if_unavailable"),
            sslcacert = properties.get("sslcacert"),
            sslclientcert = properties.get("sslclientcert"),
            sslclientkey = properties.get("sslclientkey"),
            sslverify = properties.get("sslverify"),
            throttle = properties.get("throttle"),
            assumeyes = properties.get("assumeyes"),
            deltarpm_metadata_percentage = properties.get("deltarpm_metadata_percentage"),
            deltarpm_percentage = properties.get("deltarpm_percentage"),
        )
        return repo


def get_httprepo(platformversion, name, properties):
    try:
        return platformversion.http_repos.get(name=name)
    except ObjectDoesNotExist:
        logger.info("Http repo does not exist so we create it")
        repo = HttpRepo.objects.create(
            platform_version=platformversion,
            name=name,
            path=properties.get("path"),
        )
        return repo


@receiver(import_node, sender=PuppetPlatformImporter)
def import_puppet_node(sender, instance, node, source, **kwargs): # @UnusedVariable
    """
    Import de la configuration yum.
    """
    for name, properties in source['properties'].get("classes", {}).get("yum::repo", {}).get("repos", {}).items():
        try:
            repo = get_yumrepo(node.platform_version, name, properties)
        except InternalError as error:
            msg = "Impossible de récupérer le repo yum avec les informations suivantes : "
            msg = f"platform_version: {node.platform_version}, name: {name}, properties: {str(properties)}"
            instance.error(msg)
            logger.error(error)
        else:
            repo.nodes.add(node)

    for name, properties in source['properties'].get("classes", {}).get("yum::httprepo", {}).get("repos", {}).items():
        repo = get_httprepo(node.platform_version, name, properties)
        repo.nodes.add(node)

