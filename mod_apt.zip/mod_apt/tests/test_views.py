
from django.test import Client
from django.utils import timezone

from core.tests.generic.test_views import ViewsTestCase


class YumViewsTestCase(ViewsTestCase):
    fixtures = ['refs.json', 'platform_test_omega.json']

    def create_module_objects(self):
        pass

    def setUp(self):
        super().setUp()
        self.MODULE_NAME = 'yum'
        self.create_module_objects()
        self.black_list = ['get_name_securitypackrepo', 'add_node_yumrepo', 'sync_reporeference']

    def test_urls2(self):
        '''tester toutes les urls.
        '''
        self.default_kwargs = {'pk': self.pf_version01.pk}
        self._test_responses(default_kwargs=self.default_kwargs, credentials=self.credentials)

    def test_check_template_node_detail(self):
        for n in range(1, 3):
            self._test_template_is_used2('core', 'view_node', 'mod_yum/node_detail_{0}.html'.format(n),
                                         kwargs={'pk': self.node01.pk})
