
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.utils import timezone

from core.models import Node
from core.tests.generic.test_models import ModelsTestCase
from mod_yum.models import YumRepo, YumRepoReference


class SecurityPackRepoTestCase(ModelsTestCase):
    fixtures = ['refs.json', 'platform_test_omega.json']

    def setUp(self):
        super().setUp()  # Initial data
        self.username = 'dumay'
        self.email = 'dumay@dumay.corse'
        self.password = 'dumay'
        User.objects.create_superuser(self.username, self.email, self.password)

    # Initial functions for creating new instances
    def create_security_pack(self, identifier='foo'):
        return YumRepo.objects.create(
            identifier=identifier,
            date=timezone.now(),
            repo_type='se',
            description='lorem ipsom dolor kayci...',
            platform_version=self.pf_version01
        )

    def create_yum_repo_reference(self, identifier='foo'):
        return YumRepoReference.objects.create(
            identifier=identifier,
            date=timezone.now(),
            description='lorem ipsom dolor kayci...',
            repo_type='se'
        )

    # End of initial function for creating new instances

    # Starting unit test for creating new instances basend on our model's definition

    # testing YumRepoReference instance
    # creation
    def test_create_yum_repo_reference_model(self):
        yf = self.create_yum_repo_reference()
        self.assertTrue(isinstance(yf, YumRepoReference))
        self.assertEqual(yf.__str__(), yf.identifier)

    # update
    def test_update_yum_repo_reference_model(self):
        yr = self.create_yum_repo_reference()
        yr.identifier = 'DGFiPapp_secure-2.0.1-3.DGFiP.noarch.rpm'
        yr.save()
        self.assertEqual(yr.identifier, 'DGFiPapp_secure-2.0.1-3.DGFiP.noarch.rpm')

    # we are trying to create a new node (with no configuration cobbler) with a security pack
    def creating_new_node_with_security_pack(self):
        return Node.objects.create(name='45t sg',
                                   description='Description...',
                                   platform_version=self.pf_version01,
                                   )  # a new node

    def _test_creating_new_node_with_security_pack_throws_exception(self):
        with self.assertRaises(ValidationError):
            self.creating_new_node_with_security_pack()
