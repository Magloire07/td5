
from rest_framework import serializers
from mod_yum.models import YumRepo


class RepoTypeSerializer(serializers.Serializer):
    def to_representation(self, instance):
        for i in YumRepo.YUM_REPO_REFERENCE_TYPES_CHOICES:
            if i[0] == instance:
                return i[1]


class YumRepoCompleteSerializer(serializers.ModelSerializer):
    repo_type = RepoTypeSerializer()
    nodes = serializers.StringRelatedField(many=True)

    class Meta:
        model = YumRepo
        fields = ('identifier', 'repo_type', 'base_url', 'enabled', 'description', 'nodes',
        'platform_version','timeout', 'cost', 'enablegroups', 'exclude', 'failovermethod',
        'gpgcheck', 'gpgkey', 'include', 'includepkgs', 'keepalive', 'metadata_expire',
        'mirrorlist', 'priority', 'protect', 'proxy', 'proxy_password', 'proxy_username',
        'ensure', 'bandwidth', 'gpgcakey', 'metalink', 'mirrorlist_expire', 'repo_gpgcheck',
        'retries', 's3_enabled', 'skip_if_unavailable', 'sslcacert',
        'sslclientcert', 'sslclientkey', 'sslverify', 'throttle',
        'assumeyes', 'deltarpm_metadata_percentage', 'deltarpm_percentage',
        'http_caching')

class YumRepoSerializer(serializers.ModelSerializer):
    repo_type = RepoTypeSerializer()

    class Meta:
        model = YumRepo
        fields = ('identifier', 'repo_type', 'base_url', 'enabled', 'description', 'nodes',
        'platform_version','timeout', 'cost', 'enablegroups', 'exclude', 'failovermethod',
        'gpgcheck', 'gpgkey', 'include', 'includepkgs', 'keepalive', 'metadata_expire',
        'mirrorlist', 'priority', 'protect', 'proxy', 'proxy_password', 'proxy_username',
        'ensure', 'bandwidth', 'gpgcakey', 'metalink', 'mirrorlist_expire', 'repo_gpgcheck',
        'retries', 's3_enabled', 'skip_if_unavailable', 'sslcacert',
        'sslclientcert', 'sslclientkey', 'sslverify', 'throttle',
        'assumeyes', 'deltarpm_metadata_percentage', 'deltarpm_percentage',
        'http_caching')