from django.urls import re_path
from mod_apparmor.views import node, role


app_name = 'apparmor'

urlpatterns = [
    re_path(
        r"^role/(?P<serverrole_id>\d+)/add/$",
        role.ApparmorCreateView.as_view(),
        name="add_role"
    ),
    re_path(
        r"^node/(?P<node_id>\d+)/add/$",
        node.ApparmorCreateView.as_view(),
        name="add"
    ),
    re_path(
        r"^update/(?P<pk>\d+)/$",
        node.ApparmorUpdateView.as_view(),
        name="update"
    ),
    re_path(
        r"^delete/(?P<pk>\d+)/$",
        node.ApparmorDeleteView.as_view(),
        name="delete"
    ),

    re_path(
        r"^boolean/(?P<apparmor_id>\d+)/add/$",
        node.BooleanStateCreateView .as_view(),
        name="add_boolean"
    ),
    re_path(
        r"^boolean/(?P<pk>\d+)/update/$",
        node.BooleanStateUpdateView.as_view(),
        name="update_boolean"
    ),
    re_path(
        r"^boolean/(?P<pk>\d+)/delete/$",
        node.BooleanStateDeleteView.as_view(),
        name="delete_boolean"
    ),

    re_path(
        r"^file_context_rule/(?P<apparmor_id>\d+)/add/$",
        node.FContextRuleCreateView .as_view(),
        name="add_file_context_rule"
    ),
    re_path(
        r"^file_context_rule/(?P<pk>\d+)/update/$",
        node.FContextRuleUpdateView.as_view(),
        name="update_file_context_rule"
    ),
    re_path(
        r"^file_context_rule/(?P<pk>\d+)/delete/$",
        node.FContextRuleDeleteView.as_view(),
        name="delete_file_context_rule"
    ),

    re_path(
        r"^port_rule/(?P<apparmor_id>\d+)/add/$",
        node.PortRuleCreateView .as_view(),
        name="add_port_rule"
    ),
    re_path(
        r"^port_rule/(?P<pk>\d+)/update/$",
        node.PortRuleUpdateView.as_view(),
        name="update_port_rule"
    ),
    re_path(
        r"^port_rule/(?P<pk>\d+)/delete/$",
        node.PortRuleDeleteView.as_view(),
        name="delete_port_rule"
    ),
]
