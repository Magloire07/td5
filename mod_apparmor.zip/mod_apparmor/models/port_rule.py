import logging
from django.db import models
from django.utils.translation import gettext_lazy as _
from core.models import BaseRoleSublevelChild

logger = logging.getLogger("omega.mod_apparmor")


class PortRuleManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().select_related('context_type')

    def get_by_natural_key(self, name, *args):
        from .apparmor import Apparmor
        return self.get(
            name=name,
            apparmor=Apparmor.objects.get_by_natural_key(*args),
        )


class PortRule(BaseRoleSublevelChild):
    """ Enregistrement d'une règle de contexte de port Apparmor au niveau du nœud/rôle
    """
    objects = PortRuleManager()

    PROTOCOLES = (
        ('tcp', 'tcp'),
        ('udp', 'udp'),
    )

    OPERATIONS = (
        ('a', _('add rule')),
        ('d', _('delete rule')),
        ('m', _('update rule')),
    )

    name = models.SlugField(
        verbose_name=_('name'),
    )

    apparmor = models.ForeignKey(
        'mod_apparmor.Apparmor',
        on_delete=models.CASCADE,
        related_name='port_rules',
        verbose_name=_('apparmor')
    )

    context_type = models.ForeignKey(
        'mod_apparmor.ContextType',
        on_delete=models.CASCADE,
        related_name='prules',
        verbose_name=_('domain')
    )

    protocol = models.CharField(
        max_length=5,
        verbose_name=_('protocole'),
        choices=PROTOCOLES,
    )

    description = models.CharField(
        max_length=255,
        blank=True,
        verbose_name=_('description'),
        default=''
    )

    port_range_start = models.PositiveIntegerField(
        blank=True,
        verbose_name=_('port range start'),
        help_text=_('port range start helptext'),
        null=True
    )

    port_range_stop = models.PositiveIntegerField(
        blank=True,
        verbose_name=_('port range stop'),
        help_text=_('port range stop helptext'),
        null=True
    )

    operation = models.CharField(
        max_length=1,
        verbose_name=_('operation'),
        choices=OPERATIONS,
    )

    class Meta:
        verbose_name = _('port rule')
        verbose_name_plural = _('port rules')
        unique_together = (
            ('name', 'apparmor'),
        )

    @property
    def port_range(self):
        port_range = None

        if self.port_range_start and self.port_range_stop:
            if self.port_range_start == self.port_range_stop:
                port_range = f'{self.port_range_start}'
            else:
                port_range = f'{self.port_range_start} - {self.port_range_stop}'
        else:
            if self.port_range_start:
                port_range = f'{self.port_range_start}'

        return port_range

    def attach_role_slave(self, _parent_fname, parent):
        obj = parent.port_rules.filter(name=self.name).first()

        return obj

    def check_port_range(self):
        if self.port_range_start and self.port_range_stop:
            if self.port_range_stop < self.port_range_start:
                start = self.port_range_stop
                stop = self.port_range_start
                self.port_range_start = start
                self.port_range_stop = stop
        else:
            if not self.port_range_start and self.port_range_stop:
                self.port_range_start = self.port_range_stop
                self.port_range_stop = None

    def get_absolute_url(self):
        root_url = self.get_role_root().get_absolute_url()
        return f"{root_url}#apparmor"

    def natural_key(self):
        return (self.name, ) + self.apparmor.natural_key()
    natural_key.dependencies = ['mod_apparmor.Apparmor']

    def save(self, *args, **kwargs):
        self.check_port_range()
        super().save(*args, **kwargs)
