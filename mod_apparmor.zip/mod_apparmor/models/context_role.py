import logging
from django.db import models
from django.utils.translation import gettext_lazy as _

from core.models import BaseModel

logger = logging.getLogger("omega.mod_apparmor")


class ContextRoleManager(models.Manager):
    def get_by_natural_key(self, name):
        return self.get(name=name)


class ContextRole(BaseModel):
    """ Référentiel des contextes Apparmor, champ rôle
    """
    objects = ContextRoleManager()

    name = models.CharField(
        max_length=255,
        verbose_name=_('name'),
        unique=True
    )

    class Meta:
        verbose_name = _('apparmor context_role')
        verbose_name_plural = _('apparmor context_roles')

    def __str__(self):
        return self.name

    def natural_key(self):
        return (self.name, )
