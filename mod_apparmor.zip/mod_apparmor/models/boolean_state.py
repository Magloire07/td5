import logging

from django.db import models
from django.utils.translation import gettext_lazy as _

from core.models import BaseRoleSublevelChild

logger = logging.getLogger("omega.mod_apparmor")


class BooleanStateManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().select_related('ref')

    def get_by_natural_key(self, name, *args):
        from .apparmor import Apparmor
        return self.get(
            ref__name=name,
            apparmor=Apparmor.objects.get_by_natural_key(*args),
        )


class BooleanState(BaseRoleSublevelChild):
    """ Enregistrement de l'état d'un booléen Apparmor au niveau de la configuration d'un nœud/rôle
    """
    objects = BooleanStateManager()

    apparmor = models.ForeignKey(
        'mod_apparmor.Apparmor',
        on_delete=models.CASCADE,
        related_name='booleans',
    )

    ref = models.ForeignKey(
        'mod_apparmor.Boolean',
        on_delete=models.CASCADE,
        related_name='+',
        verbose_name=_('boolean ref'),
        help_text=_('boolean ref help_text'),
    )

    ensure = models.BooleanField(
        verbose_name=_('state value'),
        help_text=_('boolean state help_text'),
    )

    description = models.CharField(
        max_length=255,
        default='',
        blank=True,
    )

    class Meta:
        verbose_name = _('boolean state')
        verbose_name_plural = _('boolean states')
        unique_together = (
            ('ref', 'apparmor'),
        )

    @property
    def name(self):
        return self.ref.name

    def attach_role_slave(self, _parent_fname, parent):
        obj = parent.booleans.filter(ref=self.ref).first()
        return obj

    def get_absolute_url(self):
        root_url = self.get_role_root().get_absolute_url()
        return f"{root_url}#apparmor"

    def natural_key(self):
        return (self.name, ) + self.apparmor.natural_key()
    natural_key.dependencies = ['mod_apparmor.Apparmor']
