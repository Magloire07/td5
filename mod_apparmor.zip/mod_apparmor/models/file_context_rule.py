import logging
from django.db import models
from django.utils.translation import gettext_lazy as _
from core.models import BaseRoleSublevelChild


logger = logging.getLogger("omega.mod_apparmor")


class FContextRuleManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().select_related('context_type')

    def get_by_natural_key(self, name, *args):
        from .apparmor import Apparmor
        return self.get(
            name=name,
            apparmor=Apparmor.objects.get_by_natural_key(*args),
        )


class FContextRule(BaseRoleSublevelChild):
    """ Enregistrement d'une règle de contexte de fichier Apparmor au niveau du nœud/rôle
    """
    objects = FContextRuleManager()

    FILE_TYPE_CHOICES = (
        ('a', _('all types and files')),
        ('b', _('file device block mode')),
        ('c', _('file device charactere mode')),
        ('d', _('dir')),
        ('f', _('regular file')),
        ('l', _('symbolic link')),
        ('p', _('pipe named')),
        ('s', _('socket unix')),
    )

    name = models.SlugField(verbose_name=_('name'))

    apparmor = models.ForeignKey(
        'mod_apparmor.Apparmor',
        on_delete=models.CASCADE,
        related_name='fcontext_rules'
    )

    context_type = models.ForeignKey(
        'mod_apparmor.ContextType',
        verbose_name=_("context type"),
        on_delete=models.CASCADE,
        related_name='fcontext_rules_ct'
    )

    path_spec = models.CharField(
        max_length=255,
        verbose_name=_('path'),
        help_text=_('fcontext_rule path_spec help_text'),
    )

    file_type = models.CharField(
        max_length=1,
        verbose_name=_('file type'),
        choices=FILE_TYPE_CHOICES,
        default='a'
    )

    description = models.CharField(
        max_length=255,
        blank=True,
        verbose_name=_('description'),
        default=''
    )

    class Meta:
        verbose_name = _('file context rule')
        verbose_name_plural = _('file context rules')
        unique_together = (
            ('name', 'apparmor'),
        )

    def attach_role_slave(self, _parent_fname, parent):
        obj = parent.fcontext_rules.filter(name=self.name).first()

        return obj

    def get_absolute_url(self):
        root_url = self.get_role_root().get_absolute_url()
        return f"{root_url}#apparmor"

    def natural_key(self):
        return (self.name, ) + self.apparmor.natural_key()
    natural_key.dependencies = ['mod_apparmor.Apparmor']
