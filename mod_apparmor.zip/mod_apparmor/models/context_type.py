import logging
from django.db import models
from django.utils.translation import gettext_lazy as _

from core.models import BaseModel

logger = logging.getLogger("omega.mod_apparmor")


class ContextTypeManager(models.Manager):
    def get_by_natural_key(self, name):
        return self.get(name=name)


class ContextType(BaseModel):
    """ Référentiel des contextes Apparmor, champ type
    """
    objects = ContextTypeManager()

    name = models.CharField(
        max_length=255,
        verbose_name=_('name'),
        unique=True
    )

    class Meta:
        verbose_name = _('apparmor context_type')
        verbose_name_plural = _('apparmor context_types')

    def __str__(self):
        return self.name

    def natural_key(self):
        return (self.name, )
