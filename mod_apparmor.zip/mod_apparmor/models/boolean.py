import logging
from django.db import models
from django.utils.translation import gettext_lazy as _

from core.models import BaseModel

logger = logging.getLogger("omega.mod_apparmor")


class BooleanManager(models.Manager):
    def get_by_natural_key(self, name):
        return self.get(name=name)


class Boolean(BaseModel):
    """ Référentiel des booléens Apparmor
    """
    objects = BooleanManager()

    name = models.CharField(
        max_length=255,
        verbose_name=_('name'),
        unique=True,
    )

    class Meta:
        verbose_name = _('apparmor boolean')
        verbose_name_plural = _('apparmor booleans')

    def __str__(self):
        return self.name

    def natural_key(self):
        return (self.name, )
