import logging

from django.db import models
from django.utils.translation import gettext_lazy as _

from core.models import BaseRoleOneToOne
from core.utils import get_root_by_natural_key, root_natural_key


logger = logging.getLogger("omega.mod_apparmor")


class ApparmorManager(models.Manager):
    def get_by_natural_key(self, *args):
        return self.get(**get_root_by_natural_key(*args))


class Apparmor(BaseRoleOneToOne):
    """ Enregistrement des paramètres Apparmor généraux au niveau du nœud/role
    """
    objects = ApparmorManager()

    NAME_CHOICES = (
        ('enforcing', _('Apparmor security policies are applied')),
        ('permissive', _('Apparmor security policies are audited but not enforced')),
        ('disabled', _('Apparmor security policies are disabled')),
    )
    POLICY_CHOICES = (
        ('targeted', _('targeted security policy')),
        ('minimum', _('minimum security policy')),
        ('mls', _('multi-level security policy')),
    )
    mode = models.CharField(
        max_length=10,
        verbose_name=_('name'),
        choices=NAME_CHOICES,
        default='enforcing'
    )
    policy = models.CharField(
        max_length=10,
        verbose_name=_('type'),
        choices=POLICY_CHOICES,
        default='targeted',
        blank=True
    )
    description = models.CharField(
        blank=True,
        max_length=255,
        verbose_name=_('description')
    )

    class Meta:
        verbose_name = _('apparmor configuration')
        verbose_name_plural = _('apparmor configurations')

    def attach_role_slave(self, _parent_fname, node):
        try:
            return node.apparmor
        except Apparmor.DoesNotExist:
            return None

    def get_absolute_url(self):
        root_url = self.get_role_root().get_absolute_url()
        return f"{root_url}#apparmor"

    def natural_key(self):
        return root_natural_key(self)
    natural_key.dependencies = ['core.Node', 'core.ServerRole']
