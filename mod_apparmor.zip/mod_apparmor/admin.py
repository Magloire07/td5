from django.contrib import admin
from mod_apparmor import models


@admin.register(models.Apparmor)
class ApparmorAdmin(admin.ModelAdmin):
    list_display = ('mode', 'policy', 'node', 'role', )
    search_fields = ('mode', 'policy', 'node', 'role', )
    readonly_fields = ('node', 'role', 'role_master', )

    def has_add_permission(self, request):
        return False


@admin.register(models.BooleanState)
class BooleanStateAdmin(admin.ModelAdmin):
    list_display = ('ref', 'ensure', 'description', )
    search_fields = ('ref', 'ensure', 'description', )
    readonly_fields = ('role_master', )
    exclude = ('apparmor', )

    def has_add_permission(self, request):
        return False


@admin.register(models.FContextRule)
class FContextRuleAdmin(admin.ModelAdmin):
    list_display = ('name', 'path_spec', 'context_type', 'file_type', 'description', )
    search_fields = ('name', 'path_spec', 'context_type', 'file_type', 'description', )
    readonly_fields = ('role_master', )
    exclude = ('apparmor', )

    def has_add_permission(self, request):
        return False


@admin.register(models.PortRule)
class PortRuleAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', )
    search_fields = ('name', 'description', )
    readonly_fields = ('role_master', )
    exclude = ('apparmor', )

    def has_add_permission(self, request):
        return False


@admin.register(models.Boolean)
class BooleanAdmin(admin.ModelAdmin):
    list_display = ('name', )
    search_fields = ('name', )


@admin.register(models.ContextRole)
class ContextRoleAdmin(admin.ModelAdmin):
    list_display = ('name', )
    search_fields = ('name', )


@admin.register(models.ContextType)
class ContextTypeAdmin(admin.ModelAdmin):
    list_display = ('name', )
    search_fields = ('name', )


@admin.register(models.ContextUser)
class ContextUserAdmin(admin.ModelAdmin):
    list_display = ('name', )
    search_fields = ('name', )
