from core.views.generic import (
    RoleOrNodeChildCreateView,
    inject_model_instance
)
from core.models import ServerRole
from mod_apparmor.models import Apparmor
from mod_apparmor.forms import ApparmorForm


class ApparmorCreateView(inject_model_instance(RoleOrNodeChildCreateView, ServerRole)):
    model = Apparmor
    form_class = ApparmorForm
    auth_scheme = 'write'

    def get_initial(self):
        return {
            'role': self.serverrole,
        }

    def get_success_url(self):
        return super().get_success_url().replace('resume', 'apparmor')
