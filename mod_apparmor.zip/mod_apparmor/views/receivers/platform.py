# -*- coding: utf-8 -*-
from django.dispatch import receiver
from django.utils.translation import gettext_lazy as _

from core.views.node import NodeListView
from core.views.generic.signals import pre_get_context
from mod_apparmor.models import (
    Apparmor, Boolean, BooleanState, FContextRule, PortRule
)
from mod_apparmor.utils import (
    get_booleans_lines_by_nodes,
    get_fcontexts_lines_by_nodes,
    get_ports_lines_by_nodes
)


@receiver(pre_get_context, sender=NodeListView)
def build_platform_view(view, **kwargs):
    storage_template_infos = [
        {
            'module_id': 'apparmor_apparmor',
            'module_title': _("Apparmor")
        }
    ]

    apparmors = list(
        Apparmor.objects.filter(node__in=view.object_list)
        .prefetch_related('node')
    )

    if len(apparmors) > 0:
        storage_template_infos.extend([
            {
                'module_id': 'apparmor_boolean',
                'module_title': _("boolean")
            },
            {
                'module_id': 'apparmor_fcontex_rule',
                'module_title': _("file context rule")
            },
            {
                'module_id': 'apparmor_port_rule',
                'module_title': _("port rule")
            }
        ])

        booleans, boolean_lines = get_booleans_lines_by_nodes(view.object_list)
        fcontexts, fcontexts_lines = get_fcontexts_lines_by_nodes(view.object_list)
        ports, ports_lines = get_ports_lines_by_nodes(view.object_list)

        view.update_modules_context(
            dict(
                apparmors=apparmors,
                booleans=booleans,
                boolean_lines=boolean_lines,
                fcontexts=fcontexts,
                fcontexts_lines=fcontexts_lines,
                ports=ports,
                ports_lines=ports_lines
            )
        )

    for tindex in range(len(storage_template_infos)):
        nb = tindex+1
        view.add_module_template(
            "mod_apparmor/node_list/panel_%i.html" % nb,
            priority=nb,
            topic=7,
            module_id=storage_template_infos[tindex]["module_id"],
            module_title=storage_template_infos[tindex]["module_title"],
        )
