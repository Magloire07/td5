# -*- coding: utf-8 -*-
from django.utils.translation import gettext_lazy as _
from django.dispatch import receiver

from core.views.server_role import ServerRoleDetailView
from core.views.generic.signals import pre_get_context
from mod_apparmor.models import (Apparmor, BooleanState, FContextRule, PortRule)


@receiver(pre_get_context, sender=ServerRoleDetailView)
def build_serverrole_view(view, **kwargs):
    storage_template_infos = [
        {
            'module_id': 'apparmor_apparmor',
            'module_title': _("Apparmor")
        }
    ]
    apparmor = Apparmor.objects.filter(role=view.object).first()

    if apparmor:
        storage_template_infos.extend([
            {
                'module_id': 'apparmor_boolean',
                'module_title': _("boolean")
            },
            {
                'module_id': 'apparmor_fcontex_rule',
                'module_title': _("file context rule")
            },
            {
                'module_id': 'apparmor_port_rule',
                'module_title': _("port rule")
            }
        ])
        view.update_modules_context(
            dict(
                apparmor=apparmor,
                booleans_states=BooleanState.objects.filter(apparmor=apparmor),
                file_context_rules=FContextRule.objects.filter(apparmor=apparmor),
                port_rules=PortRule.objects.filter(apparmor=apparmor)
            )
        )
    else:
        view.update_modules_context(
            dict(
                apparmor=apparmor
            )
        )

    for tindex in range(len(storage_template_infos)):
        nb = tindex+1
        view.add_module_template(
            "mod_apparmor/role/panel_%i.html" % nb,
            priority=nb,
            topic=9,
            module_id=storage_template_infos[tindex]["module_id"],
            module_title=storage_template_infos[tindex]["module_title"],
        )
