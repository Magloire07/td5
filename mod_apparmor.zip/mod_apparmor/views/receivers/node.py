# -*- coding: utf-8 -*-
from django.dispatch import receiver
from django.utils.translation import gettext_lazy as _

from core.views.node import NodeDetailView
from core.views.generic.signals import pre_get_context
from mod_apparmor.models import (Apparmor, BooleanState, FContextRule, PortRule)


# @receiver(pre_get_context, sender=NodeDetailView)
# def build_node_view(view, **kwargs):
    # storage_template_infos = [
    #     {
    #         'module_id': 'apparmor_apparmor',
    #         'module_title': _("Apparmor")
    #     }
    # ]
    # apparmor = Apparmor.objects.filter(node=view.object).first()

    # if apparmor:
    #     storage_template_infos.extend([
    #         {
    #             'module_id': 'apparmor_boolean',
    #             'module_title': _("boolean")
    #         },
    #         {
    #             'module_id': 'apparmor_fcontex_rule',
    #             'module_title': _("file context rule")
    #         },
    #         {
    #             'module_id': 'apparmor_port_rule',
    #             'module_title': _("port rule")
    #         }
    #     ])
    #     view.update_modules_context(
    #         dict(
    #             apparmor=apparmor,
    #             booleans_states=apparmor.booleans.all(),
    #             file_context_rules=apparmor.fcontext_rules.all(),
    #             port_rules=apparmor.port_rules.all()
    #         )
    #     )

    # for tindex in range(len(storage_template_infos)):
    #     nb = tindex+1
    #     view.add_module_template(
    #         "mod_apparmor/node/panel_%i.html" % nb,
    #         priority=nb,
    #         topic=11,
    #         module_id=storage_template_infos[tindex]["module_id"],
    #         module_title=storage_template_infos[tindex]["module_title"],
    #     )
@receiver(pre_get_context, sender=NodeDetailView)
def build_node_view(view, **kwargs): # @UnusedVariable
    view.add_module_template(
                        "mod_apparmor/node/panel_1.html" , 
                        priority=62, 
                        topic=11, 
                        module_id="apparmor",
                        module_title="Apparmor", 
                        )