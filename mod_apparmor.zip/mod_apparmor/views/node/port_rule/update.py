from core.views.generic import RoleOrNodeSubChildUpdateView
from mod_apparmor.models import PortRule
from mod_apparmor.forms import PortRuleForm


class PortRuleUpdateView(RoleOrNodeSubChildUpdateView):
    model = PortRule
    form_class = PortRuleForm
