from core.views.generic import (
    RoleOrNodeSubChildCreateView,
    inject_model_instance
)
from mod_apparmor.models import PortRule, Apparmor
from mod_apparmor.forms import PortRuleForm


class PortRuleCreateView(inject_model_instance(RoleOrNodeSubChildCreateView, Apparmor)):
    model = PortRule
    form_class = PortRuleForm
    auth_scheme = 'write'

    def get_auth_scheme_instance(self):
        return self.apparmor

    def get_initial(self):
        return {
            'apparmor': self.apparmor,
        }
