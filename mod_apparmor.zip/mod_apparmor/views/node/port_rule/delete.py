from core.views.generic import RoleOrNodeSubChildDeleteView
from mod_apparmor.models import PortRule


class PortRuleDeleteView(RoleOrNodeSubChildDeleteView):
    model = PortRule
    auth_scheme = 'write'
