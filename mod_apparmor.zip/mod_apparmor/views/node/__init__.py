from .apparmor.add import ApparmorCreateView # noqa
from .apparmor.update import ApparmorUpdateView # noqa
from .apparmor.delete import ApparmorDeleteView # noqa

from .boolean.add import BooleanStateCreateView # noqa
from .boolean.update import BooleanStateUpdateView # noqa
from .boolean.delete import BooleanStateDeleteView # noqa

from .file_context_rule.add import FContextRuleCreateView # noqa
from .file_context_rule.update import FContextRuleUpdateView # noqa
from .file_context_rule.delete import FContextRuleDeleteView # noqa

from .port_rule.add import PortRuleCreateView # noqa
from .port_rule.update import PortRuleUpdateView # noqa
from .port_rule.delete import PortRuleDeleteView # noqa
