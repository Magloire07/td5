from core.views.generic import (
    RoleOrNodeSubChildCreateView,
    inject_model_instance
)
from mod_apparmor.models import FContextRule, Apparmor
from mod_apparmor.forms import FContextRuleForm


class FContextRuleCreateView(inject_model_instance(RoleOrNodeSubChildCreateView, Apparmor)):
    model = FContextRule
    form_class = FContextRuleForm
    auth_scheme = 'write'

    def get_auth_scheme_instance(self):
        return self.apparmor

    def get_initial(self):
        return {
            'apparmor': self.apparmor,
        }
