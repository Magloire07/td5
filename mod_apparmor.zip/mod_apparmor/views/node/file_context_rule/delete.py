from core.views.generic import RoleOrNodeSubChildDeleteView
from mod_apparmor.models import FContextRule


class FContextRuleDeleteView(RoleOrNodeSubChildDeleteView):
    model = FContextRule
    auth_scheme = 'write'
