from core.views.generic import RoleOrNodeSubChildUpdateView
from mod_apparmor.models import FContextRule
from mod_apparmor.forms import FContextRuleForm


class FContextRuleUpdateView(RoleOrNodeSubChildUpdateView):
    model = FContextRule
    form_class = FContextRuleForm
