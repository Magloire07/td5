from core.views.generic import (
    RoleOrNodeSubChildCreateView,
    inject_model_instance
)
from mod_apparmor.models import BooleanState, Apparmor
from mod_apparmor.forms import BooleanStateForm


class BooleanStateCreateView(inject_model_instance(RoleOrNodeSubChildCreateView, Apparmor)):
    model = BooleanState
    form_class = BooleanStateForm
    auth_scheme = 'write'

    def get_auth_scheme_instance(self):
        return self.apparmor

    def get_initial(self):
        return {
            'apparmor': self.apparmor,
        }
