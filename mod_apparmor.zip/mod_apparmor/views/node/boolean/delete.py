from core.views.generic import RoleOrNodeSubChildDeleteView
from mod_apparmor.models import BooleanState


class BooleanStateDeleteView(RoleOrNodeSubChildDeleteView):
    model = BooleanState
    auth_scheme = 'write'
