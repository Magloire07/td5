from core.views.generic import RoleOrNodeSubChildUpdateView
from mod_apparmor.models import BooleanState
from mod_apparmor.forms import BooleanStateForm


class BooleanStateUpdateView(RoleOrNodeSubChildUpdateView):
    model = BooleanState
    form_class = BooleanStateForm
