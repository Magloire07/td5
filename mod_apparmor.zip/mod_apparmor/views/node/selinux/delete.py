from core.views.generic import RoleOrNodeChildDeleteView
from mod_apparmor.models import Apparmor


class ApparmorDeleteView(RoleOrNodeChildDeleteView):
    model = Apparmor
    auth_scheme = 'write'
