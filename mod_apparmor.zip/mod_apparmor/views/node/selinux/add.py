from core.views.generic import (
    RoleOrNodeChildCreateView,
    inject_model_instance
)
from core.models import Node
from mod_apparmor.models import Apparmor
from mod_apparmor.forms import ApparmorForm


class ApparmorCreateView(inject_model_instance(RoleOrNodeChildCreateView, Node)):
    model = Apparmor
    form_class = ApparmorForm
    auth_scheme = 'write'

    def get_initial(self):
        return {
            'node': self.node,
        }
