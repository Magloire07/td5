from core.views.generic import RoleOrNodeChildUpdateView
from mod_apparmor.models import Apparmor
from mod_apparmor.forms import ApparmorForm


class ApparmorUpdateView(RoleOrNodeChildUpdateView):
    model = Apparmor
    form_class = ApparmorForm
