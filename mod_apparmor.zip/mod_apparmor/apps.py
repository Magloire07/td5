from django.apps import AppConfig
import logging
logger = logging.getLogger("omega.mod_apparmor")


class ApparmorConfig(AppConfig):
    name = 'mod_apparmor'
    verbose_name = 'Gestion des droits Apparmor'

    def ready(self):
        self.connect_signals()

    def connect_signals(self):
        from mod_apparmor.views.receivers.node import build_node_view # noqa
        from mod_apparmor.views.receivers.serverrole import build_serverrole_view # noqa
        from mod_apparmor.views.receivers.platform import build_platform_view # noqa
        from mod_apparmor.exports.receivers import main_export_ldif_apparmor # noqa
        from mod_apparmor.exports.ansible_receivers import export_yaml_node
