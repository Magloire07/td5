
from django.test import Client
from rest_framework import status
from django.urls import reverse

from core.tests.generic.test_views import ViewsTestCase
from mod_apparmor.models import Apparmor


class ApparmorDeleteViewTestCase(ViewsTestCase):
    fixtures = ['refs.json', 'platform_test_omega.json']
    client = None
    url = None
    apparmor = None

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.MODULE_NAME = 'apparmor'
        self.apparmor = Apparmor.objects.create(node=self.node01, mode=Apparmor.NAME_CHOICES[0][0],
                                              policy=Apparmor.POLICY_CHOICES[0][0],
                                              description='descriptiopn apparmor')
        self.url = reverse(
            'apparmor:delete',
            kwargs={'pk': self.apparmor.pk}
        )
        self.client = Client()
        self.client.force_login(self.admin_user)

    def test_load_form(self):
        response = self.client.get(
            self.url
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_post_delete(self):
        response = self.client.post(
            self.url
        )
        self.assertRedirects(
            response,
            reverse('core:view_node', kwargs={'pk': self.apparmor.node.pk})
        )

        try:
            Apparmor.objects.get(
                node=self.node02
            )
        except Apparmor.DoesNotExist:
            self.assertTrue(True)
        else:
            self.assertTrue(False)
