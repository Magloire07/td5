
from django.test import Client
from django.urls import reverse
from rest_framework import status

from core.tests.generic.test_views import ViewsTestCase
from mod_apparmor.models import Apparmor


class ApparmorUpdateViewTestCase(ViewsTestCase):
    fixtures = ['refs.json', 'platform_test_omega.json']
    client = None
    url = None
    apparmor = None
    node = None

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.MODULE_NAME = 'apparmor'
        self.node = self.node01
        self.apparmor = Apparmor.objects.create(node=self.node, mode=Apparmor.NAME_CHOICES[0][0],
                                              policy=Apparmor.POLICY_CHOICES[0][0],
                                              description='descriptiopn apparmor')
        self.url = reverse(
            'apparmor:update',
            kwargs={'pk': self.apparmor.pk}
        )
        self.client = Client()
        self.client.force_login(self.admin_user)

    def test_load_form(self):
        response = self.client.get(
            self.url
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_post_update(self):
        data = {
            'mode': 'permissive',
            'policy': 'targeted',
            'description': 'dddd',
            'node': self.node.pk
        }
        response = self.client.post(
            self.url,
            data
        )

        self.assertRedirects(
            response,
            reverse('core:view_node', kwargs={'pk': self.apparmor.node.pk}) + '#apparmor'
        )

        apparmor = Apparmor.objects.get(node=self.node)

        self.assertIsInstance(
            apparmor,
            Apparmor
        )
        self.assertEqual(apparmor.mode, data['mode'])
        self.assertEqual(apparmor.policy, data['policy'])

    def test_post_update_error(self):
        data = {
            'mode': '',
            'policy': '',
            'description': 'blabla',
            'node': self.node.pk
        }
        response = self.client.post(
            self.url,
            data
        )
        self.assertEqual(
            response.status_code,
            200
        )
