from django.test import Client

from core.tests.generic.test_views import ViewsTestCase
from mod_apparmor.models import Apparmor, BooleanState, Boolean
from django.urls import reverse


class BooleanStateDeleteViewTestCase(ViewsTestCase):
    fixtures = ['refs.json', 'platform_test_omega.json']
    client = None
    node = None
    url = None
    apparmor = None

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.MODULE_NAME = 'apparmor'
        self.apparmor = Apparmor.objects.create(node=self.node01, mode=Apparmor.NAME_CHOICES[0][0],
                                              policy=Apparmor.POLICY_CHOICES[0][0],
                                              description='descriptiopn apparmor')
        self.ref = Boolean.objects.get(name='auditadm_exec_content')
        self.state = BooleanState.objects.create(ref=self.ref, apparmor=self.apparmor, ensure=True,
                                                 description='description')
        self.url = reverse(
            'apparmor:delete_boolean',
            kwargs={'pk': self.apparmor.pk}
        )
        self.client = Client()
        self.client.force_login(self.admin_user)

    def test_load_form(self):
        self._test_load_form_view('delete_boolean', kwargs={'pk': self.state.pk})

    def test_post_delete_form(self):
        state = self.state
        response = self.client.post(
            reverse(
                'apparmor:delete_boolean',
                kwargs={'pk': state.pk}
            )
        )
        self.assertRedirects(
            response,
            reverse('core:view_node', kwargs={'pk': self.apparmor.node.pk}) + '#apparmor'
        )
        try:
            BooleanState.objects.get(pk=state.pk)
        except BooleanState.DoesNotExist:
            self.assertTrue(True)
        else:
            self.assertTrue(False)
