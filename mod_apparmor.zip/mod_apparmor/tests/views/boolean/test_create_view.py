from django.test import Client

from core.tests.generic.test_views import ViewsTestCase
from mod_apparmor.models import BooleanState, Apparmor, Boolean
from rest_framework import status
from django.urls import reverse


class BooleanStateCreateViewTestCase(ViewsTestCase):
    client = None
    fixtures = ['refs.json', 'platform_test_omega.json']
    url = None
    apparmor = None

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.MODULE_NAME = 'apparmor'
        self.apparmor = Apparmor.objects.create(node=self.node01, mode=Apparmor.NAME_CHOICES[0][0],
                                              policy=Apparmor.POLICY_CHOICES[0][0],
                                              description='descriptiopn apparmor')
        self.url = reverse(
            'apparmor:add_boolean',
            kwargs={'apparmor_id': self.apparmor.pk}
        )
        self.client = Client()
        self.client.post('/accounts/login/', {'username': 'admin', 'password': 'admin'})

    def test_load_form(self):
        response = self.client.get(
            self.url
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_post_add(self):
        ref = Boolean.objects.all()[3].pk
        data = {
            'ref': ref,
            'ensure': 'on',
            'description': 'blabla',
            'apparmor': self.apparmor.pk
        }
        response = self.client.post(
            self.url,
            data
        )

        self.assertRedirects(
            response,
            reverse('core:view_node', kwargs={'pk': self.apparmor.node.pk}) + '#apparmor'
        )
        self.assertIsInstance(
            BooleanState.objects.get(apparmor=self.apparmor, ref=ref),
            BooleanState
        )

    def test_post_add_error(self):
        data = {
            'ref': '',
            'ensure': '',
            'description': '',
            'apparmor': '',
        }
        response = self.client.post(
            self.url,
            data
        )
        self.assertEqual(
            response.status_code,
            200
        )
