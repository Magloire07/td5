from django.test import Client

from core.tests.generic.test_views import ViewsTestCase
from mod_apparmor.models import BooleanState, Boolean, Apparmor
from django.urls import reverse


class BooleanStateUpdateViewTestCase(ViewsTestCase):
    fixtures = ['refs.json', 'platform_test_omega.json']
    client = None
    url = None
    apparmor = None
    state = None

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.MODULE_NAME = 'apparmor'
        self.apparmor = Apparmor.objects.create(node=self.node01, mode=Apparmor.NAME_CHOICES[0][0],
                                              policy=Apparmor.POLICY_CHOICES[0][0],
                                              description='descriptiopn apparmor')
        ref = Boolean.objects.get(name='auditadm_exec_content')
        self.state = BooleanState.objects.create(ref=ref, apparmor=self.apparmor, ensure=True,
                                                 description='description')

        self.url = reverse(
            'apparmor:update_boolean',
            kwargs={'pk': self.state.pk}
        )
        self.client = Client()
        self.client.post('/accounts/login/', {'username': 'admin', 'password': 'admin'})

    def test_load_form(self):
        self._test_load_form_view('update_boolean', kwargs={'pk': self.state.pk})

    def test_post_update(self):
        ref = Boolean.objects.all()[4]
        data = {
            'ref': ref.pk,
            'ensure': 'on',
            'description': 'blabssssla',
            'apparmor': self.apparmor.pk
        }
        response = self.client.post(
            self.url,
            data
        )

        self.assertRedirects(
            response,
            reverse('core:view_node', kwargs={'pk': self.apparmor.node.pk}) + '#apparmor'
        )
        self.assertIsInstance(BooleanState.objects.get(apparmor=self.apparmor, ref=ref), BooleanState)
        self.assertNotEqual(self.state.ref, ref)

    def test_post_update_error(self):
        data = {
            'ref': '',
            'ensure': '',
            'description': 'blabla',
            'apparmor': self.apparmor.pk,
        }
        response = self.client.post(
            self.url,
            data
        )

        self.assertEqual(
            response.status_code,
            200
        )
