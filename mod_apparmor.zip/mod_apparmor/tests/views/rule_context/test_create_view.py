
from django.test import Client
from django.urls import reverse
from rest_framework import status

from core.tests.generic.test_views import ViewsTestCase
from mod_apparmor.models import FContextRule, Apparmor, ContextType


class FContextRuleCreateViewTestCase(ViewsTestCase):
    fixtures = ['refs.json', 'platform_test_omega.json']
    client = None
    url = None
    apparmor = None

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.MODULE_NAME = 'apparmor'
        self.apparmor = Apparmor.objects.create(node=self.node01, mode=Apparmor.NAME_CHOICES[0][0],
                                              policy=Apparmor.POLICY_CHOICES[0][0],
                                              description='descriptiopn apparmor')
        self.url = reverse(
            'apparmor:add_file_context_rule',
            kwargs={'apparmor_id': self.apparmor.pk}
        )
        self.client = Client()
        self.client.force_login(self.admin_user)

    def test_load_form(self):
        response = self.client.get(
            self.url
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_post_add(self):
        context_type = ContextType.objects.get(name='bluetooth_conf_t')
        data = {
            'description': 'dsdssdds',
            'file_type': FContextRule.FILE_TYPE_CHOICES[0][0],
            'name': 'robertmouloude',
            'path_spec': '/var/log',
            'apparmor': self.apparmor.pk,
            'context_type': context_type.pk,
        }
        response = self.client.post(
            self.url,
            data
        )
        self.assertRedirects(
            response,
            reverse('core:view_node', kwargs={'pk': self.apparmor.node.pk}) + '#apparmor'
        )
        self.assertIsInstance(
            FContextRule.objects.get(apparmor=self.apparmor, name=data['name']),
            FContextRule
        )

    def test_post_add_error(self):
        data = {
            'description': 'dsdssdds',
            'file_type': '',
            'name': 'robertmouloude',
            'path_spec': '',
            'apparmor': self.apparmor.pk,
            'context_type': 2,
        }
        response = self.client.post(
            self.url,
            data
        )
        self.assertEqual(
            response.status_code,
            200
        )
