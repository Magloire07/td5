
from django.test import Client
from django.urls import reverse
from rest_framework import status

from core.tests.generic.test_views import ViewsTestCase
from mod_apparmor.models import Apparmor


class ApparmorCreateViewTestCase(ViewsTestCase):
    fixtures = ['refs.json', 'platform_test_omega.json']
    client = None
    url = None
    apparmor = None
    role = None

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.MODULE_NAME = 'apparmor'
        self.role = self.role01
        self.url = reverse(
            'apparmor:add_role',
            kwargs={'serverrole_id': self.role.pk}
        )
        self.client = Client()
        self.client.force_login(self.admin_user)

    def test_load_form(self):
        response = self.client.get(
            self.url
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_post_add(self):
        Apparmor.objects.all().delete()
        data = {
            'mode': 'enforcing',
            'policy': 'minimum',
            'description': 'blabla',
            'role': self.role.pk
        }
        response = self.client.post(
            self.url,
            data
        )
        self.assertRedirects(
            response,
            reverse('core:view_serverrole', kwargs={'pk': self.role.pk}) + '#apparmor'
        )
        self.assertIsInstance(
            Apparmor.objects.get(role=self.role),
            Apparmor
        )

    def test_post_add_error(self):
        data = {
            'mode': '',
            'policy': '',
            'description': 'blabla',
            'role': self.role.pk
        }
        response = self.client.post(
            self.url,
            data
        )
        self.assertEqual(
            response.status_code,
            200
        )
