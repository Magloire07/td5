
from django.urls import reverse
from django.test import Client

from core.tests.generic.test_views import ViewsTestCase
from mod_apparmor.models import PortRule, Apparmor, ContextType


class PortRuleCreateViewTestCase(ViewsTestCase):
    fixtures = ['refs.json', 'platform_test_omega.json']
    client = None
    url = None
    apparmor = None

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.MODULE_NAME = 'apparmor'
        self.apparmor = Apparmor.objects.create(node=self.node01, mode=Apparmor.NAME_CHOICES[0][0],
                                              policy=Apparmor.POLICY_CHOICES[0][0],
                                              description='descriptiopn apparmor')
        self.url = reverse(
            'apparmor:add_port_rule',
            kwargs={'apparmor_id': self.apparmor.pk}
        )
        self.client = Client()
        self.client.force_login(self.admin_user)

    def test_load_form(self):
        self._test_load_form_view('add_port_rule', kwargs={'apparmor_id': self.apparmor.pk})

    def test_post_add(self):
        data = {
            'description': 'dsdssdds',
            'context_type': ContextType.objects.get(name='cmirrord_exec_t').pk,
            'name': 'robertmouloude',
            'operation': 'm',
            'port_range_start': 1000,
            'port_range_stop': 2000,
            'protocol': 'tcp',
            'apparmor': self.apparmor.pk
        }
        response = self.client.post(
            self.url,
            data
        )
        self.assertRedirects(
            response,
            reverse('core:view_node', kwargs={'pk': self.apparmor.node.pk}) + '#apparmor'
        )
        self.assertIsInstance(
            PortRule.objects.get(apparmor=self.apparmor, name=data['name']),
            PortRule
        )

    def test_post_add_error(self):
        data = {
            'description': 'dsdssdds',
            'context_type': '',
            'name': '',
            'operation': 'm',
            'port_range_start': 1000,
            'port_range_stop': 2000,
            'protocol': 'tcp',
            'apparmor': self.apparmor.pk
        }
        response = self.client.post(
            self.url,
            data
        )
        self.assertEqual(
            response.status_code,
            200
        )
