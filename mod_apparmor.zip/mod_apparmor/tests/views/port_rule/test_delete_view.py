
from django.test import Client

from core.tests.generic.test_views import ViewsTestCase
from mod_apparmor.models import PortRule, Apparmor, ContextType
from rest_framework import status
from django.urls import reverse


class PortRuleUpdateViewTestCase(ViewsTestCase):
    fixtures = ['refs.json', 'platform_test_omega.json']
    client = None
    url = None
    port_rule = None
    apparmor = None

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.MODULE_NAME = 'apparmor'
        self.apparmor = Apparmor.objects.create(node=self.node01, mode=Apparmor.NAME_CHOICES[0][0],
                                              policy=Apparmor.POLICY_CHOICES[0][0],
                                              description='descriptiopn apparmor')
        self.context_type = ContextType.objects.get(name='cmirrord_exec_t')
        self.port_rule = PortRule.objects.create(apparmor=self.apparmor, name='testrule',
                                                 context_type=self.context_type,
                                                 protocol=PortRule.PROTOCOLES[0][0], operation=PortRule.OPERATIONS[0][0])
        self.url = reverse(
            'apparmor:delete_port_rule',
            kwargs={'pk': self.port_rule.pk}
        )
        self.client = Client()
        self.client.force_login(self.admin_user)

    def test_load_form(self):
        response = self.client.get(
            self.url
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_post_delete(self):
        response = self.client.post(
            self.url
        )
        self.assertRedirects(
            response,
            reverse('core:view_node', kwargs={'pk': self.apparmor.node.pk}) + '#apparmor'
        )

        try:
            PortRule.objects.get(pk=self.port_rule.pk)
        except PortRule.DoesNotExist:
            self.assertTrue(True)
        else:
            self.assertTrue(False)
