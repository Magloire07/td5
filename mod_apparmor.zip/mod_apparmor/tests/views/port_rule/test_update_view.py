
from django.test import Client

from core.tests.generic.test_views import ViewsTestCase
from mod_apparmor.models import PortRule, Apparmor, ContextType
from rest_framework import status
from django.urls import reverse


class PortRuleUpdateViewTestCase(ViewsTestCase):
    fixtures = ['refs.json', 'platform_test_omega.json']
    client = None
    url = None
    port_rule = None
    apparmor = None

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.MODULE_NAME = 'apparmor'
        self.apparmor = Apparmor.objects.create(node=self.node01, mode=Apparmor.NAME_CHOICES[0][0],
                                              policy=Apparmor.POLICY_CHOICES[0][0],
                                              description='descriptiopn apparmor')
        self.context_type = ContextType.objects.get(name='cmirrord_exec_t')
        self.port_rule = PortRule.objects.create(apparmor=self.apparmor, name='testrule', context_type=self.context_type,
                                                 protocol=PortRule.PROTOCOLES[0][0], operation=PortRule.OPERATIONS[0][0])
        self.url = reverse(
            'apparmor:update_port_rule',
            kwargs={'pk': self.port_rule.pk}
        )
        self.client = Client()
        self.client.force_login(self.admin_user)

    def test_load_form(self):
        response = self.client.get(
            self.url
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_post_update(self):
        data = {
            'description': 'dsdssdds',
            'context_type': self.context_type.pk,
            'name': 'robertmouloude',
            'operation': 'm',
            'port_range_start': 1000,
            'port_range_stop': 2000,
            'protocol': 'tcp',
            'apparmor': self.apparmor.pk
        }
        response = self.client.post(
            self.url,
            data
        )

        self.assertRedirects(
            response,
            reverse('core:view_node', kwargs={'pk': self.apparmor.node.pk}) + '#apparmor'
        )

        port_rule = PortRule.objects.get(pk=self.port_rule.pk)

        self.assertIsInstance(
            port_rule,
            PortRule
        )
        self.assertEqual(port_rule.name, data['name'])

    def test_post_update_error(self):
        data = {
            'description': 'dsdssdds',
            'context_type': '',
            'name': '',
            'operation': 'm',
            'port_range_start': 1000,
            'port_range_stop': 2000,
            'protocol': 'tcp',
            'apparmor': self.apparmor.pk
        }
        response = self.client.post(
            self.url,
            data
        )
        self.assertEqual(
            response.status_code,
            200
        )
