
from django.test import Client
from django.urls import reverse
from rest_framework import status

from core.tests.generic.test_views import ViewsTestCase


class PlatformVersionReceiversTestCase(ViewsTestCase):
    """
    Classe de test pour le fichier :py:mod:`mod_apparmor.views.receivers.platform`.
    mod_apparmor/views/receivers/platform.py    37%   19-68
    """
    fixtures = ['refs.json', 'platform_test_omega.json']
    client = None
    pv = None

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.MODULE_NAME = 'apparmor'
        self.client = Client()
        self.client.force_login(self.admin_user)
        self.pv = self.pf_version01

    def test_load_nodes(self):
        """
        Test qui va charger la page de résumé de plateforme pour vérifier que
        la mise à jour Apparmor fonctionne.
        """
        response = self.client.get(reverse("core:summary_nodes", kwargs={"pk": self.pv.pk}))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue('#apparmor' in str(response.content))
