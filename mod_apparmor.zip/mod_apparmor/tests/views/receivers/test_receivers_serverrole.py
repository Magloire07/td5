
from django.test import Client
from django.urls import reverse
from rest_framework import status

from core.tests.generic.test_views import ViewsTestCase
from core.models import ServerRole


class ServerRoleReceiversTestCase(ViewsTestCase):
    """
    Classe de test pour le fichier :py:mod:`mod_apparmor.views.receivers.platform`.
    mod_apparmor/views/receivers/serverrole.py  87%   21-35
    """
    fixtures = ['refs.json', 'platform_test_omega.json']
    client = None
    pv = None

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.MODULE_NAME = 'apparmor'
        self.client = Client()
        self.client.force_login(self.admin_user)

    def test_load_role(self):
        """
        Test qui va charger la page de rôle afin de vérifier si l'affichage répond correctement.
        """
        role = self.role01
        response = self.client.get(reverse("core:view_serverrole", kwargs={"pk": role.pk}))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue('#apparmor' in str(response.content))

    def test_load_role_empty(self):
        """
        Test qui va charger la page de rôle quand il n'a pas de configuration
        Apparmor afin de vérifier si l'affichage répond correctement.
        """
        pv = self.pf_version01
        role = ServerRole.objects.create(name='test_role', platform_version=pv)
        response = self.client.get(reverse("core:view_serverrole", kwargs={"pk": role.pk}))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue('#apparmor' in str(response.content))
