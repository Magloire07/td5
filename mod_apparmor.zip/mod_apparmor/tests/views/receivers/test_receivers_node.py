
from django.test import Client
from django.urls import reverse
from rest_framework import status

from core.tests.generic.test_views import ViewsTestCase


class NodeReceiversTestCase(ViewsTestCase):
    """
    Classe de test pour le fichier :py:mod:`mod_apparmor.views.receivers.node`.
    mod_apparmor/views/receivers/serverrole.py  40%   12-52
    """
    fixtures = ['refs.json', 'platform_test_omega.json']
    client = None
    pv = None

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.MODULE_NAME = 'apparmor'
        self.client = Client()
        self.client.force_login(self.admin_user)
        self.pv = self.pf_version01

    def test_load_node(self):
        """
        Test qui va charger la page de node afin de vérifier si l'affichage répond correctement.
        """
        node = self.node01
        response = self.client.get(reverse("core:view_node", kwargs={"pk": node.id}))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue('#apparmor' in str(response.content))
