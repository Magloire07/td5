from django.test import Client
from django.urls import reverse
from rest_framework import status

from core.tests.generic.test_models import ModelsTestCase


class ReceiversTestCase(ModelsTestCase):
    """
    Classe de test pour le fichier :py:mod:`mod_apparmor.exports.receivers`.
    """
    client = None
    fixtures = ['refs.json', 'platform_test_omega.json']
    pv = None

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.client = Client()
        self.client.post('/accounts/login/', {'username': 'admin', 'password': 'admin'})
        self.pv = self.pf_version01

    def test_generate_ldif_export(self):
        """
        Test qui va lancer un export ldif pour vérifier les ajouts
        des nouvelles informations du module `Apparmor`.
        """
        response = self.client.get(reverse('export_ldap:export_ldif', kwargs={'pk': self.pv.id}))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
