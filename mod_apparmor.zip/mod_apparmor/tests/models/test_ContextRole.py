
from core.tests.generic.test_models import ModelsTestCase
from mod_apparmor.models import ContextRole


class ContextRoleTestCase(ModelsTestCase):
    fixtures = ['refs.json', 'platform_test_omega.json']
    """
    Classe de tests pour le modèle :py:class:`mod_apparmor.models.ContextRole`.
    """
    def setUp(self):
        super().setUp()
        self.create_module_objects()

    def test_printable_string_representation(self):
        """
        Test pour valider le str lorsque l'on fait un print de l'objet ContextUser.
        """
        type = ContextRole.objects.get(name='auditadm_r')

        self.assertEqual('auditadm_r', str(type))
