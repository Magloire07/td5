
from core.tests.generic.test_models import ModelsTestCase
from mod_apparmor.models import ContextUser


class ContextUserTestCase(ModelsTestCase):
    fixtures = ['refs.json', 'platform_test_omega.json']
    """
    Classe de tests pour le modèle :py:class:`mod_apparmor.models.ContextUser`.
    """
    def setUp(self):
        super().setUp()
        self.create_module_objects()

    def test_printable_string_representation(self):
        """
        Test pour valider le str lorsque l'on fait un print de l'objet ContextUser.
        """
        type = ContextUser.objects.get(name='sysadm_u')

        self.assertEqual('sysadm_u', str(type))
