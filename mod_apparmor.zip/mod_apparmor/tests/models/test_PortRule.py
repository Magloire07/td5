from core.tests.generic.test_models import ModelsTestCase
from mod_apparmor.models import PortRule, Apparmor, ContextType


class PortRuleTestCase(ModelsTestCase):
    """
    Classe de tests pour le modèle :py:class:`mod_apparmor.models.PortRule`.
    """
    apparmor = None

    fixtures = ['refs.json', 'platform_test_omega.json']

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.apparmor = Apparmor.objects.create(
            node=self.node01
        )

    def test_property_port_range(self):
        """
        Test pour valider les différentes permutations de la propriété `port_range`.
        """
        port_rule = PortRule.objects.create(
            description='dsdssdds',
            context_type=ContextType.objects.get(name='bluetooth_conf_t'),
            name='robertmouloude',
            operation='m',
            port_range_start=1000,
            port_range_stop=2000,
            protocol='tcp',
            apparmor=self.apparmor
        )

        self.assertEqual('1000 - 2000', port_rule.port_range)

        port_rule.port_range_stop = port_rule.port_range_start
        port_rule.save()

        self.assertEqual('1000', port_rule.port_range)

        port_rule.port_range_stop = None
        port_rule.save()

        self.assertEqual('1000', port_rule.port_range)

        port_rule.port_range_stop = 1000
        port_rule.port_range_start = 2000
        port_rule.save()

        self.assertEqual('1000 - 2000', port_rule.port_range)

        port_rule.port_range_stop = 1000
        port_rule.port_range_start = None
        port_rule.save()

        self.assertEqual('1000', port_rule.port_range)
