
from core.tests.generic.test_models import ModelsTestCase


class AttachRoleSlaveTestCase(ModelsTestCase):
    fixtures = ['refs.json', 'platform_test_omega.json']
    node = None
    role = None

    def setUp(self):
        super().setUp()
        self.create_module_objects()
        self.node = self.node01
        self.role = self.role01

    def test_attach(self):
        self.test_detach()
        self.node.role = self.role
        self.node.save(refresh_roles=True)

        self.assertTrue(True)

    def test_detach(self):
        self.node.role = None
        self.node.save(refresh_roles=True)

        self.assertTrue(True)
