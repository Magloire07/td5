from django.core import management


class Command(management.BaseCommand):
    help = "Charge les fixtures pour Apparmor."

    fixtures = [
        'apparmor_booleans',
        'apparmor_roles',
        'apparmor_types',
        'apparmor_users',
    ]

    def handle(self, *args, **options):  # noqa
        return management.call_command('loaddata', *self.fixtures, **options)
