import logging
from mod_export_ansible.exports.base import AnsibleYamlExporter
from mod_export_ldap.exports import LdapNode, LdifExporter
from core.exports.signals import export_node
from core.utils.dispatch import receiver
from mod_apparmor.models import (
        BooleanState,
        Apparmor,
        FContextRule,
        PortRule
)


logger = logging.getLogger("omega.mod_apparmor")

@receiver(export_node, sender=AnsibleYamlExporter)
def export_yaml_node(sender, instance, node, parent, **kwargs):
    """
    Export des packages d'un noeud
    """



    
    omega_node=node["_node"]
    try:
        apparmor = Apparmor.objects.get(node=omega_node)
    except Apparmor.DoesNotExist:
        pass
    else:
        node["apparmor"]={}
        export_apparmor(apparmor, node["apparmor"])
        export_booleanstate(apparmor, node["apparmor"])
        export_fcontextrule(apparmor, node["apparmor"])
        export_portrule(apparmor, node["apparmor"])

def export_apparmor(apparmor, parent):
    
    parent["state"]= apparmor.mode    
    parent["policy"]= apparmor.policy



def export_booleanstate(apparmor, parent):
    booleans = BooleanState.objects.filter(apparmor=apparmor)
    
    for boolean in booleans:
        if not parent.get("boolean_states",None):
            parent["boolean_states"]=[]
        current_boolean={}
        value = str(boolean.ensure).upper()
        current_boolean["name"]= boolean.ref.name
        current_boolean["value"]= value
        parent["boolean_states"].append(current_boolean)


def export_fcontextrule(apparmor, parent):
    rules = FContextRule.objects.filter(apparmor=apparmor)
    for rule in rules:
        if not parent.get("f_context_rules",None):
            parent["f_context_rules"]=[]
        current_rule={}
        current_rule["name"]= rule.name
        current_rule["path_spec"]= rule.path_spec
        current_rule["file_type"]= rule.file_type
        current_rule["type"]= rule.context_type.name
        parent["f_context_rules"].append("current_rule")


def export_portrule(apparmor, parent):
    ports = PortRule.objects.filter(apparmor=apparmor)
    for port in ports:
        if not parent.get("port_rules",None):
            parent["port_rules"]=[]
        current_port={}
        current_port["name"]= port.name
        current_port["proto"]= port.protocol
        if port.port_range:
            current_port["range"]= port.port_range
        current_port["setype"]= port.context_type.name
        current_port["argument"]= f"-{port.operation}"
        parent["port_rules"].append(current_port)



