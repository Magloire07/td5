import logging
from mod_export_ldap.exports import LdapNode, LdifExporter
from core.exports.signals import export_node
from core.utils.dispatch import receiver
from mod_apparmor.models import (
        BooleanState,
        Apparmor,
        FContextRule,
        PortRule
)


logger = logging.getLogger("omega.mod_apparmor")


def export_apparmor(apparmor, instance, node, parent, **kwargs):
    ou = instance.get_ou("apparmor", parent=node)
    ldap_route = LdapNode(model_object=apparmor, parent=ou)
    ldap_route.set_dn("apparmorMode", apparmor.mode)
    ldap_route.set("objectClass", ["apparmor"])
    ldap_route.set("apparmorModeType", apparmor.policy)

    return ldap_route


def export_booleanstate(apparmor, ou, instance, node, parent, **kwargs):
    booleans = BooleanState.objects.filter(apparmor=apparmor)

    for boolean in booleans:
        value = str(boolean.ensure).upper()
        ldap_route = LdapNode(model_object=boolean, parent=ou)
        ldap_route.set("objectClass", ["apparmorBoolean"])
        ldap_route.set_dn("apparmorBooleanName", boolean.ref.name)
        ldap_route.set("apparmorBooleanValue", value)


def export_fcontextrule(apparmor, ou, instance, node, parent, **kwargs):
    rules = FContextRule.objects.filter(apparmor=apparmor)

    for rule in rules:
        ldap_route = LdapNode(model_object=rule, parent=ou)
        ldap_route.set("objectClass", ["apparmorFContext"])
        ldap_route.set_dn("apparmorFContext", rule.name)
        ldap_route.set("apparmorFContextPathSpec", rule.path_spec)
        ldap_route.set("apparmorFContextFileType", rule.file_type)
        ldap_route.set("apparmorType", rule.context_type.name)


def export_portrule(apparmor, ou, instance, node, parent, **kwargs):
    ports = PortRule.objects.filter(apparmor=apparmor)

    for port in ports:
        ldap_route = LdapNode(model_object=port, parent=ou)
        ldap_route.set("objectClass", ["apparmorPort"])
        ldap_route.set_dn("apparmorPort", port.name)
        ldap_route.set("apparmorProtocol", port.protocol)
        if port.port_range:
            ldap_route.set("apparmorPortRange", port.port_range)
        ldap_route.set("apparmorType", port.context_type.name)
        ldap_route.set("apparmorPortArgument", f"-{port.operation}")


@receiver(export_node, sender=LdifExporter)
def main_export_ldif_apparmor(sender, instance, node, parent, **kwargs):
    """
    Export LDIF de la configuration apparmor
    """
    try:
        apparmor = Apparmor.objects.get(node=node.instance)
    except Apparmor.DoesNotExist:
        pass
    else:
        ou = export_apparmor(apparmor, instance, node, parent, **kwargs)
        export_booleanstate(apparmor, ou, instance, node, parent, **kwargs)
        export_fcontextrule(apparmor, ou, instance, node, parent, **kwargs)
        export_portrule(apparmor, ou, instance, node, parent, **kwargs)
