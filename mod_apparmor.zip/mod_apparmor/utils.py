from mod_apparmor.models import (
    BooleanState,
    FContextRule,
    PortRule
)


def get_booleans_lines_by_nodes(nodes):
    boolean_states = BooleanState.objects.filter(apparmor__node__in=nodes)
    boolean_states_dict = {
        (bs.apparmor.node.pk, bs.name): bs.ensure for bs in boolean_states
    }

    booleans = list({
        (bs.name) for bs in boolean_states
    })

    lines = []
    for node in nodes:
        cells = []
        for boolean in booleans:
            state = boolean_states_dict.get((node.pk, boolean), None)
            cells.append(state)
        lines.append((node, cells))

    return (booleans, lines)


def get_fcontexts_lines_by_nodes(nodes):
    fcontexts_rules = FContextRule.objects.filter(apparmor__node__in=nodes)
    fcontexts_states_dict = {
        (fc.apparmor.node.pk, fc.name): True for fc in fcontexts_rules
    }

    fcontexts = list({
        (fc.name) for fc in fcontexts_rules
    })

    lines = []
    for node in nodes:
        cells = []
        for fcontext in fcontexts:
            state = fcontexts_states_dict.get((node.pk, fcontext), False)
            cells.append(state)
        lines.append((node, cells))

    return (fcontexts, lines)


def get_ports_lines_by_nodes(nodes):
    port_rules = PortRule.objects.filter(apparmor__node__in=nodes)
    port_rules_dict = {
        (pr.apparmor.node.pk, pr.name): True for pr in port_rules
    }

    ports = list({
        (pr.name) for pr in port_rules
    })

    lines = []
    for node in nodes:
        cells = []
        for port in ports:
            state = port_rules_dict.get((node.pk, port), False)
            cells.append(state)
        lines.append((node, cells))

    return (ports, lines)
