from django import forms
from mod_apparmor.models import BooleanState
from core.forms.generic import GenericModelForm


class BooleanStateForm(GenericModelForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["apparmor"].widget = forms.widgets.HiddenInput()
        self.fields["ensure"].widget = forms.widgets.NullBooleanSelect()
        self.fields["ensure"].widget.choices.pop(0)

    class Meta:
        model = BooleanState
        fields = ('ref', 'ensure', 'description', 'apparmor')
