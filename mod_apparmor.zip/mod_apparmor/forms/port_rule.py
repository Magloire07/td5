from mod_apparmor.models import PortRule
from core.forms.generic import GenericModelForm
from django import forms


class PortRuleForm(GenericModelForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields["apparmor"].widget = forms.widgets.HiddenInput()

    class Meta:
        model = PortRule
        fields = (
            'name',
            'context_type',
            'protocol',
            'port_range_start',
            'port_range_stop',
            'operation',
            'description',
            'apparmor',
        )
