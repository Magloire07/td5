from django import forms
from mod_apparmor.models import Apparmor
from core.forms.generic import GenericModelForm


class ApparmorForm(GenericModelForm):

    def __init__(self, node, role, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["node"].widget = forms.widgets.HiddenInput()
        self.fields["role"].widget = forms.widgets.HiddenInput()

    class Meta:
        model = Apparmor
        fields = ('mode', 'policy', 'description', 'node', 'role')
