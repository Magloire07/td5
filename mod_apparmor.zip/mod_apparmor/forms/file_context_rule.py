from mod_apparmor.models import FContextRule
from core.forms.generic import GenericModelForm
from django import forms


class FContextRuleForm(GenericModelForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields["apparmor"].widget = forms.widgets.HiddenInput()

    class Meta:
        model = FContextRule
        fields = (
            'name',
            'path_spec',
            'context_type',
            'file_type',
            'description',
            'apparmor',
        )
